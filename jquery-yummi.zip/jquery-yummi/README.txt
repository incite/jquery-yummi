Check test.html for usage and general reference.

Author: Julio Cesar Ody (julio.ody@incite.com).
Copyright 2009 Incite (www.incite.com).
